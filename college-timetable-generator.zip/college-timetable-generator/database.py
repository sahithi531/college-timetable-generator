"""SQLite connection and schema setup for the timetable generator."""

from pathlib import Path
import sqlite3
from typing import Union


PROJECT_DIR = Path(__file__).resolve().parent
DATABASE_DIR = PROJECT_DIR / "database"
DATABASE_PATH = DATABASE_DIR / "college_timetable.db"
PathLike = Union[str, Path]


SCHEMA = """
CREATE TABLE IF NOT EXISTS subjects (
    id               INTEGER PRIMARY KEY,
    code             TEXT NOT NULL UNIQUE COLLATE NOCASE,
    name             TEXT NOT NULL,
    sessions_per_week INTEGER NOT NULL DEFAULT 1 CHECK (sessions_per_week > 0),
    duration_slots   INTEGER NOT NULL DEFAULT 1 CHECK (duration_slots > 0),
    created_at       TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS faculty (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL,
    email       TEXT UNIQUE COLLATE NOCASE,
    created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS rooms (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL UNIQUE COLLATE NOCASE,
    capacity    INTEGER NOT NULL CHECK (capacity > 0),
    room_type   TEXT NOT NULL DEFAULT 'classroom',
    created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS batches (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL UNIQUE COLLATE NOCASE,
    size        INTEGER NOT NULL CHECK (size > 0),
    created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS time_slots (
    id          INTEGER PRIMARY KEY,
    day_of_week INTEGER NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
    start_time  TEXT NOT NULL,
    end_time    TEXT NOT NULL,
    label       TEXT,
    CHECK (start_time < end_time),
    UNIQUE (day_of_week, start_time, end_time)
);

-- A subject can be taught by multiple faculty, and a faculty member can teach
-- multiple subjects. RESTRICT prevents deleting records still referenced here.
CREATE TABLE IF NOT EXISTS faculty_subjects (
    faculty_id INTEGER NOT NULL REFERENCES faculty(id) ON DELETE RESTRICT,
    subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE RESTRICT,
    PRIMARY KEY (faculty_id, subject_id)
);

-- Defines which subjects are required by each student batch.
CREATE TABLE IF NOT EXISTS batch_subjects (
    batch_id   INTEGER NOT NULL REFERENCES batches(id) ON DELETE CASCADE,
    subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE RESTRICT,
    PRIMARY KEY (batch_id, subject_id)
);

-- Only listed slots are considered available for the faculty member.
CREATE TABLE IF NOT EXISTS faculty_availability (
    faculty_id  INTEGER NOT NULL REFERENCES faculty(id) ON DELETE CASCADE,
    time_slot_id INTEGER NOT NULL REFERENCES time_slots(id) ON DELETE CASCADE,
    PRIMARY KEY (faculty_id, time_slot_id)
);

CREATE INDEX IF NOT EXISTS idx_faculty_subjects_subject
    ON faculty_subjects(subject_id);
CREATE INDEX IF NOT EXISTS idx_batch_subjects_subject
    ON batch_subjects(subject_id);
CREATE INDEX IF NOT EXISTS idx_faculty_availability_slot
    ON faculty_availability(time_slot_id);
"""


def get_connection(db_path: PathLike = DATABASE_PATH) -> sqlite3.Connection:
    """Return a configured connection; callers are responsible for closing it."""
    path = Path(db_path)
    if str(db_path) != ":memory:":
        path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(str(db_path))
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def initialize_database(db_path: PathLike = DATABASE_PATH) -> None:
    """Create the schema if it does not already exist."""
    connection = get_connection(db_path)
    try:
        connection.executescript(SCHEMA)
    finally:
        connection.close()


if __name__ == "__main__":
    initialize_database()
    print(f"Database initialized at {DATABASE_PATH}")
