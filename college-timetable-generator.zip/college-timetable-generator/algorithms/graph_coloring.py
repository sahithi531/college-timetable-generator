"""Graph-coloring timetable scheduler.

Each class meeting is a vertex, resource conflicts form edges, and each
available time slot is a color. The scheduler uses a deterministic
degree-ordered greedy coloring and records every decision it makes.

Input class mappings must have a unique ``id`` and may contain:

* ``faculty_id`` or ``faculty_ids``
* ``room_id`` or ``room_ids``
* ``batch_id`` or ``batch_ids``
* ``available_time_slot_ids`` to restrict the class to particular slots

The returned assignments and decision trace use IDs so they can be rendered
directly by the Flask application.
"""

from collections import defaultdict
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Set, Tuple


ResourceSet = Set[Any]


def _values(item: Mapping[str, Any], singular: str, plural: str) -> ResourceSet:
    """Read a singular or plural resource field as a set."""
    raw = item.get(plural)
    if raw is None:
        raw = item.get(singular)
    if raw is None:
        return set()
    if isinstance(raw, (str, bytes)) or not isinstance(raw, Iterable):
        return {raw}
    return set(raw)


def _class_resources(item: Mapping[str, Any]) -> Dict[str, ResourceSet]:
    return {
        "faculty": _values(item, "faculty_id", "faculty_ids"),
        "room": _values(item, "room_id", "room_ids"),
        "batch": _values(item, "batch_id", "batch_ids"),
    }


def build_conflict_graph(
    classes: Sequence[Mapping[str, Any]],
) -> Tuple[Dict[Any, Set[Any]], List[Dict[str, Any]]]:
    """Build an undirected graph and explain each edge by shared resources."""
    ids = [item.get("id") for item in classes]
    if any(class_id is None for class_id in ids):
        raise ValueError("Every class must have an 'id'.")
    if len(ids) != len(set(ids)):
        raise ValueError("Class IDs must be unique.")

    resources = {item["id"]: _class_resources(item) for item in classes}
    neighbors: Dict[Any, Set[Any]] = {class_id: set() for class_id in ids}
    edges: List[Dict[str, Any]] = []

    for index, first_id in enumerate(ids):
        for second_id in ids[index + 1 :]:
            shared = {
                kind: sorted(
                    resources[first_id][kind] & resources[second_id][kind],
                    key=str,
                )
                for kind in ("faculty", "room", "batch")
            }
            reasons = {kind: values for kind, values in shared.items() if values}
            if reasons:
                neighbors[first_id].add(second_id)
                neighbors[second_id].add(first_id)
                edges.append(
                    {"class_ids": [first_id, second_id], "reasons": reasons}
                )
    return neighbors, edges


def generate_timetable(
    classes: Sequence[Mapping[str, Any]],
    time_slots: Sequence[Mapping[str, Any]],
    faculty_availability: Optional[Mapping[Any, Iterable[Any]]] = None,
) -> Dict[str, Any]:
    """Color the conflict graph using available time-slot IDs.

    ``faculty_availability`` maps faculty IDs to iterable time-slot IDs. When
    supplied, a class with faculty can use only slots available to every one
    of its faculty. A class-level ``available_time_slot_ids`` restriction is
    also honored. If a faculty member is absent from the availability mapping,
    their slots are treated as unspecified (unrestricted).

    A conflict-free partial timetable is returned when not every vertex can
    be colored. Unscheduled classes and their rejection reasons appear in the
    result, alongside a full decision trace.
    """
    slot_ids = [slot.get("id") for slot in time_slots]
    if any(slot_id is None for slot_id in slot_ids):
        raise ValueError("Every time slot must have an 'id'.")
    if len(slot_ids) != len(set(slot_ids)):
        raise ValueError("Time-slot IDs must be unique.")

    neighbors, edges = build_conflict_graph(classes)
    slot_set = set(slot_ids)
    availability = {
        faculty_id: set(available_slots)
        for faculty_id, available_slots in (faculty_availability or {}).items()
    }
    class_by_id = {item["id"]: item for item in classes}

    # Highest degree first reduces the chance that a constrained vertex is
    # left with no color. Input order breaks ties for reproducible decisions.
    order_index = {item["id"]: index for index, item in enumerate(classes)}
    ordered_ids = sorted(
        order_index,
        key=lambda class_id: (-len(neighbors[class_id]), order_index[class_id]),
    )

    eligible_slots: Dict[Any, List[Any]] = {}
    for class_id in ordered_ids:
        class_item = class_by_id[class_id]
        candidates = set(slot_set)
        if class_item.get("available_time_slot_ids") is not None:
            candidates &= set(class_item["available_time_slot_ids"])
        for faculty_id in _class_resources(class_item)["faculty"]:
            if faculty_id in availability:
                candidates &= availability[faculty_id]
        eligible_slots[class_id] = [slot_id for slot_id in slot_ids if slot_id in candidates]

    assigned: Dict[Any, Any] = {}
    decisions: List[Dict[str, Any]] = [
        {
            "step": 0,
            "action": "graph_built",
            "class_count": len(classes),
            "edge_count": len(edges),
            "edges": edges,
            "coloring_order": ordered_ids,
            "rule": "Assign each class the first eligible slot not used by an already-colored neighbor.",
        }
    ]
    unscheduled: List[Dict[str, Any]] = []

    for step, class_id in enumerate(ordered_ids, start=1):
        attempted: List[Dict[str, Any]] = []
        chosen_slot = None
        for slot_id in eligible_slots[class_id]:
            blockers = [
                neighbor_id
                for neighbor_id in ordered_ids
                if neighbor_id in neighbors[class_id]
                and assigned.get(neighbor_id) == slot_id
            ]
            attempted.append(
                {
                    "time_slot_id": slot_id,
                    "accepted": not blockers,
                    "blocked_by_classes": blockers,
                }
            )
            if not blockers:
                chosen_slot = slot_id
                break

        if chosen_slot is None:
            reason = (
                "No eligible time slots were available for this class."
                if not eligible_slots[class_id]
                else "Every eligible slot was already used by a conflicting class."
            )
            unscheduled.append({"class_id": class_id, "reason": reason})
            decisions.append(
                {
                    "step": step,
                    "action": "class_unscheduled",
                    "class_id": class_id,
                    "eligible_time_slot_ids": eligible_slots[class_id],
                    "attempts": attempted,
                    "reason": reason,
                }
            )
            continue

        assigned[class_id] = chosen_slot
        decisions.append(
            {
                "step": step,
                "action": "slot_assigned",
                "class_id": class_id,
                "time_slot_id": chosen_slot,
                "eligible_time_slot_ids": eligible_slots[class_id],
                "attempts": attempted,
                "conflicting_class_ids": sorted(neighbors[class_id], key=str),
            }
        )

    assignments = [
        {"class_id": class_id, "time_slot_id": assigned[class_id]}
        for class_id in order_index
        if class_id in assigned
    ]
    return {
        "assignments": assignments,
        "unscheduled": unscheduled,
        "conflict_edges": edges,
        "decisions": decisions,
        "complete": not unscheduled,
    }


# Short alias for callers that prefer an algorithm-oriented function name.
color_timetable = generate_timetable
