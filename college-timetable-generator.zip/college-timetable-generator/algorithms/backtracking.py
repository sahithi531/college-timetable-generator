"""Backtracking timetable generator with constraint and decision tracing."""

from collections.abc import Iterable, Mapping, Sequence
from typing import Any, Dict, List, Optional, Set, Tuple

from .greedy import _class_resources, _room_candidates, _room_fits


def generate_timetable(
    classes: Sequence[Mapping[str, Any]],
    time_slots: Sequence[Mapping[str, Any]],
    rooms: Sequence[Mapping[str, Any]],
    faculty_availability: Optional[Mapping[Any, Iterable[Any]]] = None,
) -> Dict[str, Any]:
    """Search for a complete timetable by recursively trying slot-room pairs.

    Classes accept the same fields as ``algorithms.greedy.generate_timetable``:
    ``id``, faculty and batch IDs, optional room and slot restrictions, and an
    optional class size for room-capacity checks. Faculty availability maps
    faculty IDs to iterable time-slot IDs; faculty absent from the map are
    treated as having unspecified availability.

    The search returns the first complete timetable it finds. If none exists,
    ``assignments`` contains the deepest valid partial timetable reached and
    ``complete`` is false. ``assignment_count`` counts every tentative
    placement; ``backtrack_count`` counts every placement undone.
    """
    class_ids = [item.get("id") for item in classes]
    slot_ids = [item.get("id") for item in time_slots]
    room_ids = [item.get("id") for item in rooms]
    for label, ids in (("class", class_ids), ("time-slot", slot_ids), ("room", room_ids)):
        if any(value is None for value in ids):
            raise ValueError(f"Every {label} must have an 'id'.")
        if len(ids) != len(set(ids)):
            raise ValueError(f"{label.capitalize()} IDs must be unique.")

    classes_by_id = {item["id"]: item for item in classes}
    rooms_by_id = {item["id"]: item for item in rooms}
    resources = {item["id"]: _class_resources(item) for item in classes}
    class_room_options = {
        class_id: set(_room_candidates(classes_by_id[class_id], room_ids))
        for class_id in class_ids
    }

    # Order constrained classes first: larger potential conflict degree, then
    # fewer room options, then original input order for deterministic ties.
    neighbors: Dict[Any, Set[Any]] = {class_id: set() for class_id in class_ids}
    edge_reasons: List[Dict[str, Any]] = []
    for index, first_id in enumerate(class_ids):
        for second_id in class_ids[index + 1 :]:
            reasons = {}
            shared_faculty = resources[first_id]["faculty"] & resources[second_id]["faculty"]
            shared_batches = resources[first_id]["batch"] & resources[second_id]["batch"]
            shared_rooms = class_room_options[first_id] & class_room_options[second_id]
            if shared_faculty:
                reasons["faculty"] = sorted(shared_faculty, key=str)
            if shared_batches:
                reasons["batch"] = sorted(shared_batches, key=str)
            if shared_rooms:
                reasons["potential_rooms"] = sorted(shared_rooms, key=str)
            if reasons:
                neighbors[first_id].add(second_id)
                neighbors[second_id].add(first_id)
                edge_reasons.append({"class_ids": [first_id, second_id], "reasons": reasons})

    input_order = {class_id: index for index, class_id in enumerate(class_ids)}
    ordered_ids = sorted(
        class_ids,
        key=lambda class_id: (
            -len(neighbors[class_id]),
            len(class_room_options[class_id]),
            input_order[class_id],
        ),
    )
    availability = {
        faculty_id: set(slots)
        for faculty_id, slots in (faculty_availability or {}).items()
    }

    assigned: Dict[Any, Dict[str, Any]] = {}
    decisions: List[Dict[str, Any]] = [
        {
            "step": 0,
            "action": "search_initialized",
            "class_count": len(classes),
            "conflict_edges": edge_reasons,
            "processing_order": ordered_ids,
            "rule": "Tentatively assign one class, validate the entire current timetable, then recurse or undo.",
        }
    ]
    counts = {"assignments": 0, "backtracks": 0}
    deepest_assignment: Dict[Any, Dict[str, Any]] = {}
    deepest_depth = 0

    def validate_state() -> List[Dict[str, Any]]:
        """Return all constraint violations in the current partial timetable."""
        violations: List[Dict[str, Any]] = []
        assigned_ids = list(assigned)
        for class_id in assigned_ids:
            class_item = classes_by_id[class_id]
            assignment = assigned[class_id]
            slot_id = assignment["time_slot_id"]
            room_id = assignment["room_id"]

            if slot_id not in slot_ids:
                violations.append({"class_id": class_id, "constraint": "unknown_time_slot"})
            if room_id not in room_ids:
                violations.append({"class_id": class_id, "constraint": "unknown_room"})
            if class_item.get("available_time_slot_ids") is not None and slot_id not in set(
                class_item["available_time_slot_ids"]
            ):
                violations.append({"class_id": class_id, "constraint": "class_time_slot_availability"})
            for faculty_id in resources[class_id]["faculty"]:
                if faculty_id in availability and slot_id not in availability[faculty_id]:
                    violations.append(
                        {
                            "class_id": class_id,
                            "constraint": "faculty_availability",
                            "faculty_id": faculty_id,
                            "time_slot_id": slot_id,
                        }
                    )
            if room_id in rooms_by_id and not _room_fits(class_item, rooms_by_id[room_id]):
                violations.append({"class_id": class_id, "constraint": "room_capacity", "room_id": room_id})

        for index, first_id in enumerate(assigned_ids):
            first = assigned[first_id]
            for second_id in assigned_ids[index + 1 :]:
                second = assigned[second_id]
                if first["time_slot_id"] != second["time_slot_id"]:
                    continue
                if resources[first_id]["faculty"] & resources[second_id]["faculty"]:
                    violations.append(
                        {"class_ids": [first_id, second_id], "constraint": "faculty_clash"}
                    )
                if first["room_id"] == second["room_id"]:
                    violations.append(
                        {"class_ids": [first_id, second_id], "constraint": "room_clash"}
                    )
                if resources[first_id]["batch"] & resources[second_id]["batch"]:
                    violations.append(
                        {"class_ids": [first_id, second_id], "constraint": "batch_clash"}
                    )
        return violations

    def search(position: int) -> bool:
        nonlocal deepest_assignment, deepest_depth
        if position == len(ordered_ids):
            return True

        class_id = ordered_ids[position]
        class_item = classes_by_id[class_id]
        allowed_rooms = class_room_options[class_id]

        # Try every supplied pair in stable order. Placing even an unavailable
        # pair temporarily ensures the trace records its failed validation.
        for slot_id in slot_ids:
            for room_id in room_ids:
                if room_id not in allowed_rooms:
                    continue
                assigned[class_id] = {"time_slot_id": slot_id, "room_id": room_id}
                counts["assignments"] += 1
                violations = validate_state()
                decisions.append(
                    {
                        "step": len(decisions),
                        "action": "assignment_checked",
                        "class_id": class_id,
                        "time_slot_id": slot_id,
                        "room_id": room_id,
                        "valid": not violations,
                        "violations": violations,
                    }
                )

                if not violations:
                    if len(assigned) > deepest_depth:
                        deepest_depth = len(assigned)
                        deepest_assignment = {key: value.copy() for key, value in assigned.items()}
                    if search(position + 1):
                        return True

                # Invalid choices and valid choices that lead to a dead end
                # are both undone before trying the next candidate.
                del assigned[class_id]
                counts["backtracks"] += 1
                decisions.append(
                    {
                        "step": len(decisions),
                        "action": "assignment_undone",
                        "class_id": class_id,
                        "time_slot_id": slot_id,
                        "room_id": room_id,
                        "reason": (
                            "Constraint violations were found."
                            if violations
                            else "No complete timetable could be found from this choice."
                        ),
                        "backtrack_count": counts["backtracks"],
                    }
                )
        return False

    complete = search(0)
    final_assignment = assigned if complete else deepest_assignment
    final_assignments = [
        {
            "class_id": class_id,
            "time_slot_id": final_assignment[class_id]["time_slot_id"],
            "room_id": final_assignment[class_id]["room_id"],
        }
        for class_id in ordered_ids
        if class_id in final_assignment
    ]
    decisions.append(
        {
            "step": len(decisions),
            "action": "search_complete" if complete else "search_exhausted",
            "complete": complete,
            "assignment_count": counts["assignments"],
            "backtrack_count": counts["backtracks"],
            "final_assignment_count": len(final_assignments),
        }
    )
    return {
        "assignments": final_assignments,
        "unscheduled_class_ids": [
            class_id for class_id in ordered_ids if class_id not in final_assignment
        ],
        "complete": complete,
        "assignment_count": counts["assignments"],
        "backtrack_count": counts["backtracks"],
        "decisions": decisions,
        "conflict_edges": edge_reasons,
        "processing_order": ordered_ids,
    }


backtracking_timetable = generate_timetable
