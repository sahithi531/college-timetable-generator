"""Degree-ordered greedy timetable assignment.

Each class is considered in descending conflict degree. For each class, the
algorithm tries time slots and rooms in the supplied order and commits to the
first pair that satisfies resource and availability constraints.
"""

from collections.abc import Iterable, Mapping, Sequence
from typing import Any, Dict, List, Optional, Set, Tuple


def _resource_ids(item: Mapping[str, Any], singular: str, plural: str) -> Set[Any]:
    value = item.get(plural)
    if value is None:
        value = item.get(singular)
    if value is None:
        return set()
    if isinstance(value, (str, bytes)) or not isinstance(value, Iterable):
        return {value}
    return set(value)


def _class_resources(item: Mapping[str, Any]) -> Dict[str, Set[Any]]:
    return {
        "faculty": _resource_ids(item, "faculty_id", "faculty_ids"),
        "batch": _resource_ids(item, "batch_id", "batch_ids"),
    }


def _room_candidates(
    class_item: Mapping[str, Any], room_ids: List[Any]
) -> List[Any]:
    """Use per-class room choices when present; otherwise use every room."""
    requested = class_item.get("available_room_ids")
    if requested is None:
        requested = class_item.get("room_ids")
    if requested is None:
        requested = class_item.get("room_id")
    if requested is None:
        return list(room_ids)
    if isinstance(requested, (str, bytes)) or not isinstance(requested, Iterable):
        requested = [requested]
    allowed = set(requested)
    return [room_id for room_id in room_ids if room_id in allowed]


def _room_fits(class_item: Mapping[str, Any], room: Mapping[str, Any]) -> bool:
    """Check room capacity if class size and room capacity are provided."""
    room_capacity = room.get("capacity")
    class_size = class_item.get("student_count", class_item.get("batch_size"))
    return room_capacity is None or class_size is None or room_capacity >= class_size


def generate_timetable(
    classes: Sequence[Mapping[str, Any]],
    time_slots: Sequence[Mapping[str, Any]],
    rooms: Sequence[Mapping[str, Any]],
    faculty_availability: Optional[Mapping[Any, Iterable[Any]]] = None,
) -> Dict[str, Any]:
    """Generate a greedy timetable and a trace of all slot/room decisions.

    Class mappings need a unique ``id`` and may contain ``faculty_id`` /
    ``faculty_ids``, ``batch_id`` / ``batch_ids``, ``room_id`` / ``room_ids``
    (to restrict room choices), ``available_room_ids``,
    ``available_time_slot_ids``, and ``student_count`` or ``batch_size``.
    Faculty availability maps faculty IDs to the IDs of allowed time slots. If
    a faculty member is absent from that mapping, availability is unspecified
    and does not restrict their class.

    The first feasible pair wins. If no pair is feasible, the class is listed
    as unscheduled; earlier assignments are not moved or recolored.
    """
    class_ids = [item.get("id") for item in classes]
    slot_ids = [item.get("id") for item in time_slots]
    room_ids = [item.get("id") for item in rooms]
    for label, ids in (("class", class_ids), ("time-slot", slot_ids), ("room", room_ids)):
        if any(value is None for value in ids):
            raise ValueError(f"Every {label} must have an 'id'.")
        if len(ids) != len(set(ids)):
            raise ValueError(f"{label.capitalize()} IDs must be unique.")

    classes_by_id = {item["id"]: item for item in classes}
    rooms_by_id = {room["id"]: room for room in rooms}
    resources = {item["id"]: _class_resources(item) for item in classes}

    # Potential room overlap contributes to degree for ordering. Room clashes
    # are checked against the room actually selected during assignment.
    possible_rooms = {
        class_id: set(_room_candidates(classes_by_id[class_id], room_ids))
        for class_id in class_ids
    }
    neighbors: Dict[Any, Set[Any]] = {class_id: set() for class_id in class_ids}
    edge_reasons: List[Dict[str, Any]] = []
    for index, first_id in enumerate(class_ids):
        for second_id in class_ids[index + 1 :]:
            shared_faculty = resources[first_id]["faculty"] & resources[second_id]["faculty"]
            shared_batches = resources[first_id]["batch"] & resources[second_id]["batch"]
            shared_rooms = possible_rooms[first_id] & possible_rooms[second_id]
            reasons = {}
            if shared_faculty:
                reasons["faculty"] = sorted(shared_faculty, key=str)
            if shared_batches:
                reasons["batch"] = sorted(shared_batches, key=str)
            if shared_rooms:
                reasons["potential_rooms"] = sorted(shared_rooms, key=str)
            if reasons:
                neighbors[first_id].add(second_id)
                neighbors[second_id].add(first_id)
                edge_reasons.append({"class_ids": [first_id, second_id], "reasons": reasons})

    input_order = {class_id: index for index, class_id in enumerate(class_ids)}
    ordered_ids = sorted(
        class_ids,
        key=lambda class_id: (-len(neighbors[class_id]), input_order[class_id]),
    )
    slot_lookup = {slot_id: slot for slot_id, slot in zip(slot_ids, time_slots)}
    availability = {
        faculty_id: set(available_slots)
        for faculty_id, available_slots in (faculty_availability or {}).items()
    }

    assigned: Dict[Any, Dict[str, Any]] = {}
    decisions: List[Dict[str, Any]] = [
        {
            "step": 0,
            "action": "conflict_graph_built",
            "class_count": len(classes),
            "edge_count": len(edge_reasons),
            "edges": edge_reasons,
            "conflict_degrees": {
                class_id: len(neighbors[class_id]) for class_id in ordered_ids
            },
            "processing_order": ordered_ids,
            "rule": "Process highest conflict degree first; for each class, choose the first feasible time-slot and room pair.",
        }
    ]
    unscheduled: List[Dict[str, Any]] = []

    for step, class_id in enumerate(ordered_ids, start=1):
        class_item = classes_by_id[class_id]
        class_faculty = resources[class_id]["faculty"]
        class_batches = resources[class_id]["batch"]

        eligible_slots = list(slot_ids)
        if class_item.get("available_time_slot_ids") is not None:
            allowed_slots = set(class_item["available_time_slot_ids"])
            eligible_slots = [slot for slot in eligible_slots if slot in allowed_slots]
        for faculty_id in class_faculty:
            if faculty_id in availability:
                allowed_slots = availability[faculty_id]
                eligible_slots = [slot for slot in eligible_slots if slot in allowed_slots]

        candidate_rooms = _room_candidates(class_item, room_ids)
        attempts: List[Dict[str, Any]] = []
        chosen: Optional[Tuple[Any, Any]] = None

        for slot_id in eligible_slots:
            for room_id in candidate_rooms:
                room = rooms_by_id[room_id]
                blockers = []
                for other_id, assignment in assigned.items():
                    if assignment["time_slot_id"] != slot_id:
                        continue
                    reasons = []
                    if class_faculty & resources[other_id]["faculty"]:
                        reasons.append("faculty")
                    if room_id == assignment["room_id"]:
                        reasons.append("room")
                    if class_batches & resources[other_id]["batch"]:
                        reasons.append("batch")
                    if reasons:
                        blockers.append({"class_id": other_id, "reasons": reasons})

                rejection_reasons = []
                if not _room_fits(class_item, room):
                    rejection_reasons.append("room_capacity")
                if blockers:
                    rejection_reasons.extend(
                        reason
                        for blocker in blockers
                        for reason in blocker["reasons"]
                    )
                accepted = not rejection_reasons
                attempt = {
                    "time_slot_id": slot_id,
                    "room_id": room_id,
                    "accepted": accepted,
                    "rejected_for": sorted(set(rejection_reasons)),
                    "blocking_classes": blockers,
                }
                attempts.append(attempt)
                if accepted:
                    chosen = (slot_id, room_id)
                    break
            if chosen is not None:
                break

        if chosen is None:
            if not eligible_slots:
                reason = "No time slot satisfies the class and faculty availability constraints."
            elif not candidate_rooms:
                reason = "No room is available for this class."
            else:
                reason = "Every time-slot and room pair violates a resource or capacity constraint."
            unscheduled.append({"class_id": class_id, "reason": reason})
            decisions.append(
                {
                    "step": step,
                    "action": "class_unscheduled",
                    "class_id": class_id,
                    "eligible_time_slot_ids": eligible_slots,
                    "candidate_room_ids": candidate_rooms,
                    "attempts": attempts,
                    "reason": reason,
                }
            )
            continue

        slot_id, room_id = chosen
        assigned[class_id] = {"time_slot_id": slot_id, "room_id": room_id}
        decisions.append(
            {
                "step": step,
                "action": "class_assigned",
                "class_id": class_id,
                "time_slot_id": slot_id,
                "room_id": room_id,
                "time_slot": dict(slot_lookup[slot_id]),
                "attempts": attempts,
                "conflict_degree": len(neighbors[class_id]),
            }
        )

    assignments = [
        {
            "class_id": class_id,
            "time_slot_id": assigned[class_id]["time_slot_id"],
            "room_id": assigned[class_id]["room_id"],
        }
        for class_id in ordered_ids
        if class_id in assigned
    ]
    return {
        "assignments": assignments,
        "unscheduled": unscheduled,
        "conflict_edges": edge_reasons,
        "processing_order": ordered_ids,
        "decisions": decisions,
        "complete": not unscheduled,
    }


greedy_timetable = generate_timetable
