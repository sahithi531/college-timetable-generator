"""Reproducible smoke tests for all three scheduling strategies."""

import unittest

from algorithms.backtracking import generate_timetable as backtracking
from algorithms.graph_coloring import generate_timetable as graph_coloring
from algorithms.greedy import generate_timetable as greedy


def sample_data():
    subjects = [
        {"id": sid, "code": f"DAA{sid}", "name": f"Subject {sid}"}
        for sid in range(1, 6)
    ]
    faculty = [{"id": fid, "name": f"Faculty {fid}"} for fid in range(1, 4)]
    rooms = [
        {"id": 1, "name": "Room 101", "capacity": 50},
        {"id": 2, "name": "Lab 202", "capacity": 40},
    ]
    batches = [
        {"id": 1, "name": "CSE-A", "size": 35},
        {"id": 2, "name": "CSE-B", "size": 30},
    ]
    slots = [
        {"id": slot_id, "day_of_week": 0, "start_time": f"{8 + slot_id:02d}:00", "end_time": f"{9 + slot_id:02d}:00"}
        for slot_id in range(1, 7)
    ]
    teacher_for_subject = {1: 1, 2: 1, 3: 2, 4: 2, 5: 3}
    classes = []
    class_id = 1
    for batch in batches:
        for subject in subjects:
            classes.append(
                {
                    "id": class_id,
                    "subject_id": subject["id"],
                    "subject_code": subject["code"],
                    "faculty_id": teacher_for_subject[subject["id"]],
                    "batch_id": batch["id"],
                    "batch_size": batch["size"],
                }
            )
            class_id += 1
    availability = {
        1: {1, 2, 3, 4},
        2: {3, 4, 5, 6},
        3: {1, 6},
    }
    return subjects, faculty, rooms, batches, slots, classes, availability


def add_graph_coloring_rooms(assignments, classes, rooms):
    """Mirror the app's room allocation for the time-slot-only colorer."""
    classes_by_id = {item["id"]: item for item in classes}
    occupied = {}
    for assignment in assignments:
        slot_id = assignment["time_slot_id"]
        used = occupied.setdefault(slot_id, set())
        size = classes_by_id[assignment["class_id"]]["batch_size"]
        room = next(
            (room for room in rooms if room["id"] not in used and room["capacity"] >= size),
            None,
        )
        if room is None:
            return False
        assignment["room_id"] = room["id"]
        used.add(room["id"])
    return True


class TimetableAlgorithmTests(unittest.TestCase):
    def assert_valid_schedule(self, result, classes, availability):
        self.assertTrue(result["complete"], result)
        class_map = {item["id"]: item for item in classes}
        assignments = result["assignments"]
        self.assertEqual(len(assignments), len(classes))
        faculty_by_slot = set()
        room_by_slot = set()
        batch_by_slot = set()
        for assignment in assignments:
            item = class_map[assignment["class_id"]]
            slot_id = assignment["time_slot_id"]
            self.assertIn(slot_id, availability[item["faculty_id"]])
            faculty_key = (slot_id, item["faculty_id"])
            room_key = (slot_id, assignment["room_id"])
            batch_key = (slot_id, item["batch_id"])
            self.assertNotIn(faculty_key, faculty_by_slot, "faculty clash")
            self.assertNotIn(room_key, room_by_slot, "room clash")
            self.assertNotIn(batch_key, batch_by_slot, "batch clash")
            faculty_by_slot.add(faculty_key)
            room_by_slot.add(room_key)
            batch_by_slot.add(batch_key)

    def test_all_algorithms_generate_valid_timetables(self):
        subjects, faculty, rooms, batches, slots, classes, availability = sample_data()
        self.assertEqual((len(subjects), len(faculty), len(rooms), len(batches)), (5, 3, 2, 2))
        self.assertGreater(len(slots), 1)
        for algorithm in (greedy, graph_coloring, backtracking):
            with self.subTest(algorithm=algorithm.__module__):
                if algorithm is graph_coloring:
                    result = algorithm(classes, slots, availability)
                    self.assertTrue(add_graph_coloring_rooms(result["assignments"], classes, rooms))
                    result["complete"] = result["complete"] and len(result["assignments"]) == len(classes)
                else:
                    result = algorithm(classes, slots, rooms, availability)
                self.assert_valid_schedule(result, classes, availability)

    def test_impossible_schedule_is_reported_without_clashes(self):
        rooms = [{"id": 1, "name": "Small Room", "capacity": 40}]
        slots = [{"id": 1, "day_of_week": 0, "start_time": "09:00", "end_time": "10:00"}]
        classes = [
            {"id": 1, "faculty_id": 1, "batch_id": 1, "batch_size": 30},
            {"id": 2, "faculty_id": 1, "batch_id": 1, "batch_size": 30},
        ]
        availability = {1: {1}}
        for algorithm in (greedy, graph_coloring, backtracking):
            with self.subTest(algorithm=algorithm.__module__):
                if algorithm is graph_coloring:
                    result = algorithm(classes, slots, availability)
                    self.assertTrue(add_graph_coloring_rooms(result["assignments"], classes, rooms))
                else:
                    result = algorithm(classes, slots, rooms, availability)
                self.assertFalse(result["complete"])
                self.assertLess(len(result["assignments"]), len(classes))
                self.assertTrue(result.get("unscheduled") or result.get("unscheduled_class_ids"))
                self.assertTrue(result.get("decisions"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
