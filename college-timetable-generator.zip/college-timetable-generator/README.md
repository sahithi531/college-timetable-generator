# College Timetable Generator

A Flask and SQLite application for entering college scheduling data and generating a timetable with Greedy, Graph Coloring, or Backtracking.

## Run locally

```bash
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

Open <http://127.0.0.1:5000>. The SQLite database is created at `database/college_timetable.db`; weekday time slots are added the first time the app starts.

Add rooms and subjects, then add faculty and batches. Link subjects to faculty and batches in the data forms. Faculty with no selected availability slots are treated as available in every configured slot. Generate a schedule from the home page and open a run to review its assignments and algorithm trace.
