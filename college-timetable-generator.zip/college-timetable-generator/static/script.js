document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".flash-close").forEach((button) => {
    button.addEventListener("click", () => button.closest(".flash")?.remove());
  });

  document.querySelectorAll("select[multiple]").forEach((select) => {
    select.addEventListener("keydown", (event) => {
      if (event.key === "Escape") select.blur();
    });
  });

  const generator = document.querySelector(".generate-form");
  generator?.addEventListener("submit", () => {
    const button = generator.querySelector("button[type='submit']");
    if (button) {
      button.disabled = true;
      button.innerHTML = "Generating timetable <span>…</span>";
    }
  });
});
