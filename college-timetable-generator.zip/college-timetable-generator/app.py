"""Flask web application for the college timetable generator."""

import json
import sqlite3
from contextlib import closing

from flask import Flask, abort, flash, redirect, render_template, request, url_for

from database import get_connection, initialize_database
from algorithms.backtracking import generate_timetable as run_backtracking
from algorithms.graph_coloring import generate_timetable as run_graph_coloring
from algorithms.greedy import generate_timetable as run_greedy


app = Flask(__name__)
app.secret_key = "replace-this-with-a-random-secret-key"

ALGORITHMS = {
    "greedy": ("Greedy", run_greedy),
    "graph_coloring": ("Graph Coloring", run_graph_coloring),
    "backtracking": ("Backtracking", run_backtracking),
}
DEFAULT_PERIODS = (
    ("09:00", "10:00"),
    ("10:00", "11:00"),
    ("11:00", "12:00"),
    ("12:00", "13:00"),
    ("14:00", "15:00"),
    ("15:00", "16:00"),
)
DAY_NAMES = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")


def _initialize_app_data():
    """Initialize schema, default weekday slots, and saved timetable runs."""
    initialize_database()
    with closing(get_connection()) as connection:
        connection.execute(
            """CREATE TABLE IF NOT EXISTS timetable_runs (
                id INTEGER PRIMARY KEY,
                algorithm TEXT NOT NULL,
                complete INTEGER NOT NULL CHECK (complete IN (0, 1)),
                assignments_json TEXT NOT NULL,
                decisions_json TEXT NOT NULL,
                unscheduled_json TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )"""
        )
        connection.executemany(
            "INSERT OR IGNORE INTO time_slots (day_of_week, start_time, end_time, label) VALUES (?, ?, ?, ?)",
            [
                (day, start, end, f"{DAY_NAMES[day]} {start}-{end}")
                for day in range(5)
                for start, end in DEFAULT_PERIODS
            ],
        )
        connection.commit()


def _fetch_all(sql, parameters=()):
    with closing(get_connection()) as connection:
        return [dict(row) for row in connection.execute(sql, parameters).fetchall()]


def _fetch_one(sql, parameters=()):
    with closing(get_connection()) as connection:
        row = connection.execute(sql, parameters).fetchone()
        return dict(row) if row else None


def _save_form_record(sql, values, relationship_rows=()):
    """Save one form record and any supplied relationship rows atomically."""
    with closing(get_connection()) as connection:
        try:
            cursor = connection.execute(sql, values)
            record_id = cursor.lastrowid
            for relation_sql, relation_values in relationship_rows:
                connection.executemany(relation_sql, relation_values(record_id))
            connection.commit()
            return record_id
        except Exception:
            connection.rollback()
            raise


def _build_class_meetings():
    """Expand batch-subject links into individual class meeting vertices."""
    rows = _fetch_all(
        """SELECT b.id AS batch_id, b.name AS batch_name, b.size AS batch_size,
                  s.id AS subject_id, s.code AS subject_code, s.name AS subject_name,
                  s.sessions_per_week, s.duration_slots
           FROM batch_subjects bs
           JOIN batches b ON b.id = bs.batch_id
           JOIN subjects s ON s.id = bs.subject_id
           ORDER BY b.id, s.id"""
    )
    classes = []
    next_id = 1
    for row in rows:
        faculty = _fetch_all(
            """SELECT f.id, f.name FROM faculty_subjects fs
               JOIN faculty f ON f.id = fs.faculty_id
               WHERE fs.subject_id = ? ORDER BY f.id""",
            (row["subject_id"],),
        )
        for occurrence in range(1, row["sessions_per_week"] + 1):
            # Rotate among faculty linked as eligible subject instructors.
            selected_faculty = faculty[(occurrence - 1) % len(faculty)] if faculty else None
            classes.append(
                {
                    "id": next_id,
                    "subject_id": row["subject_id"],
                    "subject_code": row["subject_code"],
                    "subject_name": row["subject_name"],
                    "batch_id": row["batch_id"],
                    "batch_name": row["batch_name"],
                    "batch_size": row["batch_size"],
                    "faculty_id": selected_faculty["id"] if selected_faculty else None,
                    "faculty_name": selected_faculty["name"] if selected_faculty else "Not assigned",
                    "occurrence": occurrence,
                    "duration_slots": row["duration_slots"],
                }
            )
            next_id += 1
    return classes


def _faculty_availability():
    rows = _fetch_all(
        "SELECT faculty_id, time_slot_id FROM faculty_availability ORDER BY faculty_id, time_slot_id"
    )
    availability = {}
    for row in rows:
        availability.setdefault(row["faculty_id"], []).append(row["time_slot_id"])
    return availability


def _decorate_assignments(result, classes, slots, rooms, algorithm_key):
    """Attach names and fill room assignments for the time-slot-only colorer."""
    classes_by_id = {item["id"]: item for item in classes}
    slots_by_id = {item["id"]: item for item in slots}
    rooms_by_id = {item["id"]: item for item in rooms}
    occupied_rooms = {}
    room_decisions = []
    extra_unscheduled = []
    decorated = []

    for raw in result.get("assignments", []):
        class_id = raw["class_id"]
        class_item = classes_by_id[class_id]
        slot_id = raw["time_slot_id"]
        room_id = raw.get("room_id")

        if algorithm_key == "graph_coloring":
            used = occupied_rooms.setdefault(slot_id, set())
            room_id = next(
                (
                    room["id"]
                    for room in rooms
                    if room["id"] not in used
                    and room["capacity"] >= class_item["batch_size"]
                ),
                None,
            )
            if room_id is None:
                extra_unscheduled.append(
                    {"class_id": class_id, "reason": "No free room with enough capacity for the assigned time slot."}
                )
                room_decisions.append(
                    {"action": "room_unavailable", "class_id": class_id, "time_slot_id": slot_id}
                )
                continue
            used.add(room_id)
            room_decisions.append(
                {
                    "action": "room_assigned_after_coloring",
                    "class_id": class_id,
                    "time_slot_id": slot_id,
                    "room_id": room_id,
                }
            )

        decorated.append(
            {
                **raw,
                "class": class_item,
                "time_slot": slots_by_id[slot_id],
                "room_id": room_id,
                "room": rooms_by_id.get(room_id),
            }
        )

    result["assignments"] = decorated
    result.setdefault("unscheduled", []).extend(extra_unscheduled)
    if room_decisions:
        result.setdefault("decisions", []).append(
            {"step": len(result.get("decisions", [])), "action": "room_allocation", "details": room_decisions}
        )
    result["complete"] = not result.get("unscheduled") and len(decorated) == len(classes)
    return result


@app.get("/")
def home():
    counts = {}
    for table in ("subjects", "faculty", "rooms", "batches", "time_slots"):
        row = _fetch_one(f"SELECT COUNT(*) AS count FROM {table}")
        counts[table] = row["count"]
    recent_runs = _fetch_all(
        "SELECT id, algorithm, complete, created_at FROM timetable_runs ORDER BY id DESC LIMIT 5"
    )
    return render_template("index.html", counts=counts, recent_runs=recent_runs, algorithms=ALGORITHMS)


@app.get("/add-data")
def add_data():
    return render_template(
        "add_data.html",
        subjects=_fetch_all("SELECT id, code, name FROM subjects ORDER BY code"),
        faculty=_fetch_all("SELECT id, name, email FROM faculty ORDER BY name"),
        rooms=_fetch_all("SELECT id, name, capacity, room_type FROM rooms ORDER BY name"),
        batches=_fetch_all("SELECT id, name, size FROM batches ORDER BY name"),
        time_slots=_fetch_all(
            "SELECT id, day_of_week, start_time, end_time, label FROM time_slots ORDER BY day_of_week, start_time"
        ),
    )


@app.post("/add/subjects")
def add_subject():
    try:
        code = request.form.get("code", "").strip()
        name = request.form.get("name", "").strip()
        sessions = int(request.form.get("sessions_per_week", "1"))
        duration = int(request.form.get("duration_slots", "1"))
        if not code or not name or sessions < 1 or duration < 1:
            raise ValueError("Enter a subject code, name, and positive session/duration values.")
        faculty_ids = [int(value) for value in request.form.getlist("faculty_ids")]
        batch_ids = [int(value) for value in request.form.getlist("batch_ids")]
        _save_form_record(
            "INSERT INTO subjects (code, name, sessions_per_week, duration_slots) VALUES (?, ?, ?, ?)",
            (code, name, sessions, duration),
            [
                ("INSERT INTO faculty_subjects (faculty_id, subject_id) VALUES (?, ?)", lambda new_id: [(fid, new_id) for fid in faculty_ids]),
                ("INSERT INTO batch_subjects (batch_id, subject_id) VALUES (?, ?)", lambda new_id: [(bid, new_id) for bid in batch_ids]),
            ],
        )
        flash(f"Subject {code} added.", "success")
    except (ValueError, sqlite3.IntegrityError) as error:
        flash(f"Could not add subject: {error}", "error")
    return redirect(url_for("add_data"))


@app.post("/add/faculty")
def add_faculty():
    try:
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip() or None
        if not name:
            raise ValueError("Faculty name is required.")
        subject_ids = [int(value) for value in request.form.getlist("subject_ids")]
        slot_ids = [int(value) for value in request.form.getlist("time_slot_ids")]
        relationships = [
            ("INSERT INTO faculty_subjects (faculty_id, subject_id) VALUES (?, ?)", lambda new_id: [(new_id, sid) for sid in subject_ids])
        ]
        if slot_ids:
            relationships.append(
                ("INSERT INTO faculty_availability (faculty_id, time_slot_id) VALUES (?, ?)", lambda new_id: [(new_id, tid) for tid in slot_ids])
            )
        _save_form_record("INSERT INTO faculty (name, email) VALUES (?, ?)", (name, email), relationships)
        flash(f"Faculty member {name} added.", "success")
    except (ValueError, sqlite3.IntegrityError) as error:
        flash(f"Could not add faculty: {error}", "error")
    return redirect(url_for("add_data"))


@app.post("/add/rooms")
def add_room():
    try:
        name = request.form.get("name", "").strip()
        capacity = int(request.form.get("capacity", "0"))
        room_type = request.form.get("room_type", "classroom").strip() or "classroom"
        if not name or capacity < 1:
            raise ValueError("Enter a room name and a positive capacity.")
        _save_form_record(
            "INSERT INTO rooms (name, capacity, room_type) VALUES (?, ?, ?)",
            (name, capacity, room_type),
        )
        flash(f"Room {name} added.", "success")
    except (ValueError, sqlite3.IntegrityError) as error:
        flash(f"Could not add room: {error}", "error")
    return redirect(url_for("add_data"))


@app.post("/add/batches")
def add_batch():
    try:
        name = request.form.get("name", "").strip()
        size = int(request.form.get("size", "0"))
        if not name or size < 1:
            raise ValueError("Enter a batch name and a positive student count.")
        subject_ids = [int(value) for value in request.form.getlist("subject_ids")]
        _save_form_record(
            "INSERT INTO batches (name, size) VALUES (?, ?)",
            (name, size),
            [("INSERT INTO batch_subjects (batch_id, subject_id) VALUES (?, ?)", lambda new_id: [(new_id, sid) for sid in subject_ids])],
        )
        flash(f"Batch {name} added.", "success")
    except (ValueError, sqlite3.IntegrityError) as error:
        flash(f"Could not add batch: {error}", "error")
    return redirect(url_for("add_data"))


@app.post("/generate")
def generate():
    algorithm_key = request.form.get("algorithm", "greedy")
    if algorithm_key not in ALGORITHMS:
        flash("Choose a valid scheduling algorithm.", "error")
        return redirect(url_for("home"))

    classes = _build_class_meetings()
    slots = _fetch_all(
        "SELECT id, day_of_week, start_time, end_time, label FROM time_slots ORDER BY day_of_week, start_time"
    )
    rooms = _fetch_all("SELECT id, name, capacity, room_type FROM rooms ORDER BY name")
    if not classes:
        flash("Add subjects and link them to at least one batch before generating a timetable.", "error")
        return redirect(url_for("add_data"))
    if not slots or not rooms:
        flash("The database needs time slots and rooms before a timetable can be generated.", "error")
        return redirect(url_for("add_data"))

    try:
        label, algorithm = ALGORITHMS[algorithm_key]
        if algorithm_key == "graph_coloring":
            result = algorithm(classes, slots, _faculty_availability())
        else:
            result = algorithm(classes, slots, rooms, _faculty_availability())
        result = _decorate_assignments(result, classes, slots, rooms, algorithm_key)
        unscheduled = result.get("unscheduled", result.get("unscheduled_class_ids", []))
        with closing(get_connection()) as connection:
            cursor = connection.execute(
                """INSERT INTO timetable_runs
                   (algorithm, complete, assignments_json, decisions_json, unscheduled_json)
                   VALUES (?, ?, ?, ?, ?)""",
                (
                    algorithm_key,
                    int(result["complete"]),
                    json.dumps(result.get("assignments", [])),
                    json.dumps(result.get("decisions", [])),
                    json.dumps(unscheduled),
                ),
            )
            run_id = cursor.lastrowid
            connection.commit()
        flash(f"{label} timetable generated with {len(result.get('assignments', []))} assignments.", "success")
        return redirect(url_for("view_timetable", run_id=run_id))
    except (ValueError, sqlite3.IntegrityError) as error:
        flash(f"Could not generate the timetable: {error}", "error")
        return redirect(url_for("home"))


@app.get("/timetable")
def latest_timetable():
    latest = _fetch_one("SELECT id FROM timetable_runs ORDER BY id DESC LIMIT 1")
    if latest is None:
        flash("No timetable has been generated yet.", "error")
        return redirect(url_for("home"))
    return redirect(url_for("view_timetable", run_id=latest["id"]))


@app.get("/timetable/<int:run_id>")
def view_timetable(run_id):
    run = _fetch_one("SELECT * FROM timetable_runs WHERE id = ?", (run_id,))
    if run is None:
        abort(404)
    label = ALGORITHMS.get(run["algorithm"], (run["algorithm"], None))[0]
    assignments = json.loads(run["assignments_json"])
    decisions = json.loads(run["decisions_json"])
    unscheduled = json.loads(run["unscheduled_json"])
    assignments.sort(
        key=lambda row: (
            row["time_slot"]["day_of_week"],
            row["time_slot"]["start_time"],
            row["class"]["batch_name"],
        )
    )
    return render_template(
        "timetable.html",
        run=run,
        algorithm_label=label,
        assignments=assignments,
        decisions=decisions,
        unscheduled=unscheduled,
        day_names=DAY_NAMES,
        decisions_json=json.dumps(decisions, indent=2),
    )


_initialize_app_data()

if __name__ == "__main__":
    app.run(debug=True)
